package com.backend.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
class ShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
