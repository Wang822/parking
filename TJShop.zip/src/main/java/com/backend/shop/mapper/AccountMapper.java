package com.backend.shop.mapper;


import com.backend.shop.pojo.Account;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface AccountMapper extends BaseMapper<Account> {

}
